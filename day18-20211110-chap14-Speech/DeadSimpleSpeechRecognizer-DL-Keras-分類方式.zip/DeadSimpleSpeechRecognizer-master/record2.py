import pyaudio
import sys
from array import array
from sys import byteorder

chunk = 1024
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 44100
RECORD_SECONDS = 5
THRESHOLD = 500

p = pyaudio.PyAudio()

stream = p.open(format=FORMAT,
                channels=CHANNELS, 
                rate=RATE, 
                input=True,
                output=True,
                frames_per_buffer=chunk)

print ("* recording")

import wave
wf = wave.open('./demo.wav', 'wb')
wf.setnchannels(CHANNELS)
sample_width = p.get_sample_size(FORMAT)
wf.setsampwidth(sample_width)
wf.setframerate(RATE)
r = array('h')

for i in range(0, int(44100 / chunk * RECORD_SECONDS)):
    data = stream.read(chunk)
    # check for silence here by comparing the level with 0 (or some threshold) for 
    # the contents of data.
    # then write data or not to a file
    snd_data = array('h', data)
    if byteorder == 'big':
        snd_data.byteswap()
    r.extend(snd_data)
    if max(snd_data) > THRESHOLD:
        wf.writeframes(data)
    # else:
        # print(max(data))
    
wf.close()

print ("* done")

stream.stop_stream()
stream.close()
p.terminate()