# DeadSimpleSpeechRecognizer
CNN based Minimal model for recognizing word
